FILE NAME: R4006-B0001-02_R01_FAB_TTM.ZIP

      ITEM DESCRIPTION                                 FILE NAME
      GERBER FORMAT INFORMATION                        art_param.txt
      GERBER FORMAT INFORMATION                        art_aper.txt
                                                       RS274X  5.5A

      GERBER ARTWORK FILES OF THE FOLLOWING
      ARTWORK LAYER # 01 - COMPONENT SIDE              R4006-B0001-02_R01_L01.art
      ARTWORK LAYER # 02 - GND PLANE                   R4006-B0001-02_R01_L02.art
      ARTWORK LAYER # 03 - SIGNAL LAYER                R4006-B0001-02_R01_L03.art
      ARTWORK LAYER # 04 - GND PLANE                   R4006-B0001-02_R01_L04.art
      ARTWORK LAYER # 05 - POWER PLANE                 R4006-B0001-02_R01_L05.art
      ARTWORK LAYER # 06 - POWER PLANE                 R4006-B0001-02_R01_L06.art
      ARTWORK LAYER # 07 - GND PLANE                   R4006-B0001-02_R01_L07.art
      ARTWORK LAYER # 08 - SIGNAL LAYER                R4006-B0001-02_R01_L08.art
      ARTWORK LAYER # 09 - GND PLANE                   R4006-B0001-02_R01_L09.art
      ARTWORK LAYER # 10 - SOLDER SIDE                 R4006-B0001-02_R01_L10.art


      ARTWORK BACKDRILL FILE                           R4006-B0001-02_R01_bd_1-7.art
      ARTWORK BACKDRILL FILE                           R4006-B0001-02_R01_bd_10-9.art


      SOLDERPASTE PRIMARY TOP                          R4006-B0001-02_R01_TPM.art
      SOLDERPASTE SECONDARY BOTTOM                     R4006-B0001-02_R01_BPM.art
      SOLDERMASK PRIMARY TOP                           R4006-B0001-02_R01_TSM.art
      SOLDERMASK SECONDARY BOTTOM                      R4006-B0001-02_R01_BSM.art
      SILKSCREEN PRIMARY TOP                           R4006-B0001-02_R01_TSS.art
      SILKSCREEN SECONDARY BOTTOM                      R4006-B0001-02_R01_BSS.art
      BOARD OUTLINE                                    R4006-B0001-02_R01_OTL.art
      FABRICATION DRAWING GERBER FORMAT                R4006-B0001-02_R01_FAB.art


      N/C DRILL DATA                                   R4006-B0001-02_R01-1-10.drl
      N/C ROUTE                                        R4006-B0001-02_R01_1-10.rou

      BACKDRILL DRILL DATA                             R4006-B0001-02_R01-bd-1-7.drl
      BACKDRILL DRILL DATA                             R4006-B0001-02_R01-bd-10-9.drl

      N/C DRILL/ROUTE PARAMETER FILE                   nc_param.txt
      N/C DRILL/ROUTE PARAMETER FILE                   ncdrill.log
      N/C ROUTE                                        ncroute.log
      IPC NET LIST FILE                                R4006-B0001-02_R01_NET.ipc
      Slot Hole Report                                 Slot_Hole_Report.txt

      FABRICATION DRAWING PDF FORMAT                   R4006-B0001-02_R01_FAB.pdf                                       

      Stack up                                         R4006-B0001_FB_Timing card _Stackup_10L_1.57mm_TU863+_V1.1_09222021.pdf
      PANEL DRAWING PDF FILE                           R4006-B0001-02-PN-E1.pdf
                                                       R4006-B0001-02-PN-E1.dxf
                            
